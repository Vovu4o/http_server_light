#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main() {
    char str[] = "GET /index.html";
    char *filename = strtok(str, "GET /");
    printf("%s\n", filename);
    while (filename != NULL) {
        printf("%s\n", filename);
        filename = strtok(NULL, "/");
    }
    return 0;
}